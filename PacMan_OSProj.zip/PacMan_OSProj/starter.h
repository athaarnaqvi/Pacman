#pragma once
#include <iostream>
#include<chrono>
#include <pthread.h>
#include <unistd.h> // for usleep
#include <mutex>
#include "gameText.h"
#include "cntrgame.h"
#include "maze.h"
#include "pac.h"
#include "ghost.h"


using namespace std;
using namespace sf;

class Starter {
public:
    Event sfEvt;
    Maze maze;
    Pac<Starter>* pac;
    Ghost<Starter> *Blinky, *Pinky, *Inky,*Clyde;

    int attackInterval=15; // 15 sec
    int scaterInterval=7; // 7 sec
    int blueInterval = 6;	
    int delay;
    int curTime;
    pthread_mutex_t mtx;
    pthread_t gamethread;
    pthread_t ghStatusThread; //don't touch this
    pthread_t ghStatusThreadB; // blinkey
    pthread_t ghStatusThreadP;  //pinkey
    pthread_t ghStatusThreadI;  //inky
    pthread_t ghStatusThreadC;  //clyde
    Texture backText;
    Texture backFlashText;
    Sprite backSpr;	

    bool intro = false;
    bool isCollid = false;
    bool lifeWin = false;
    bool toNextLevel = false;
    bool gamestart = true;
    GameText *gameText;
    RenderWindow* win;

    Starter(RenderWindow *window, Texture* sprTexture){
       
        cout << "Starter class OK - Start game" << endl;		
        win = window;
        gameStatus = Demo;
        backText.loadFromFile("texture/map1.png");
        backFlashText.loadFromFile("texture/mapB.png"); //will do it in the end
        backSpr.setTexture(backText);
        maze.initMaze();
        pac = new Pac<Starter>(sprTexture,this);
        Blinky = new Ghost<Starter>(sprTexture, 1,this);
        Pinky = new Ghost<Starter>(sprTexture, 2,this);
        Inky = new Ghost<Starter>(sprTexture, 3,this);
        Clyde = new Ghost<Starter>(sprTexture, 4,this);	
        gameText = new GameText();
        Gameloop();
       // pthread_create(&gamethread, NULL, &Starter::gameloopHelper, this);
       
    }
    static void* gameloopHelper(void* arg) {
         static_cast<Starter*>(arg)->Gameloop();
         return NULL;
    }

    void Gameloop(){
        
        while (win->isOpen())
            {
                //ghost animation:
                
               Blinky->loopanimation();
               Pinky->loopanimation();
               Inky->loopanimation();
               Clyde->loopanimation();
                //pacman animation:
                sleep( milliseconds  (pac->delayLoop ) );                   
                pac-> pacAnim  = pac->pacAnim + 0.4;  
                if (pac->pacAnim > 3) { pac->pacAnim = 0; }          
                pac->animation();
                win->clear();			
                if (gameStatus == Play)
                {	
                    if(gamestart){
                         pac->setGridPosition(pac->startX,pac->startY); 
                         gamestart = false;
                    }
                   
                    //pac->pacSpr.setPosition(pac->pacPos);	
                    	
                    drawLife(win);
                    maze.drawWall(win);
                    win->draw(backSpr);
                    win->draw(gameText->gameOverTxt);
                    win->draw(gameText->scoreTxt);
                    win->draw(gameText->levelTxt);   
                }		
                else
                {  

                    win->draw(gameText->enterTxt); 
                    win->draw( Blinky->getNameTxt());
                    win->draw(Pinky->getNameTxt());
                    win->draw(Inky->getNameTxt());
                    win->draw(Clyde->getNameTxt()); 
                }
                
               
              
            //if (pac->dotsEat == 20) { nextLevel(); }
            if ( CntrGame::dotsEat == maze.dotsCount) {gameOver();} ////gameover
            while (win->pollEvent(sfEvt))
            {

                if (sfEvt.type == Event::Closed) { win->close(); }
                else if (sfEvt.type == Event::KeyPressed)
                {
                   // cout<<"key Entered" <<endl;
                    if (gameStatus == Demo && sfEvt.key.code == Keyboard::Enter)
                    {
                        startGame();

                    }
                    
                    pac->rotation(sfEvt.key.code);
                }
            }

              win->draw(pac->getSprite());
              win->draw(Blinky->getSprite());
              win->draw(Pinky->getSprite());
              win->draw(Inky->getSprite());
              win->draw(Clyde->getSprite());
              win->display();	
            }  	
    }

void drawLife( RenderWindow *win)
    {		
        if (pac->pacLife < 0) { return; }
        Sprite spr;
        for (int i = 0; i < pac->pacLife; i++)
        {
            spr = pac->getLifeSpr();
            spr.setPosition( Vector2f(30*i, 24*30) );
            (*win).draw( spr );
        }
    }	
void setBlueGhost()
    {
        if (CntrGame::pacIsDead) { return; }
        cout << "Blue Status"<<endl;				
       // if (ghStatusThread.joinable()) { ghStatusThread.detach(); }	
       if (pthread_tryjoin_np(ghStatusThreadB, NULL) == 0 || pthread_tryjoin_np(ghStatusThreadI, NULL) == 0 || pthread_tryjoin_np(ghStatusThreadP, NULL) == 0  || pthread_tryjoin_np(ghStatusThreadC, NULL) == 0  ) {
            pthread_detach(ghStatusThreadB);
            pthread_detach(ghStatusThreadP);
            pthread_detach(ghStatusThreadI);
            pthread_detach(ghStatusThreadC);
      }
       	
        sleep(milliseconds(20));
        ghostStatus = Blue;

        creatGhostThr();
        // gmSound->play(GameSound::PlSound::Blue);
        //gmSound->stop(GameSound::PlSound::Siren);
    }

void collidToPac()
    {	
        cout<<"in Collide to pac for checking"<<endl;	
        CntrGame::pacIsDead = true;
        pac->pacLife--;
        isCollid = true;		
        stopAll();
        if (pac->pacLife < 0) 
        {			
            gameOver();
        }		
    }
void gameOver()
    {				 		
        gameStatus = Demo;
        CntrGame::score = 0;
        CntrGame::level = 0;
        lifeWin = false;
        gameText->scoreTxt.setString("SCORE: 0");
        pac->stop();
        Blinky->stop();
        Pinky->stop();
        Inky->stop();
        Clyde->stop();	
        resetPacGhost();
        resetLevel();			
    }

void startGame()
    {				
        maze.redrawDot();
        gameText->gameOverTxt.setString("");
        pac->pacLife = 3;		
        gameStatus = Play;
        resetPacGhost();		
        intro = true;
        CntrGame::gameRun = true;
        CntrGame::level=1;
        CntrGame::score=0;
        CntrGame::dotsEat = 0;
        blueInterval = 6; 
        startLevel();
    }

//---
void startLevel()
    {		 
        if (intro)
        {
            intro = false;		 
            
        }
        isCollid = false;
        ghostStatus = Scater;
        creatGhostThr();    
        CntrGame::gameRun = true;
        pac->run();	
        gameText->levelTxt.setString("LEVEL: " + to_string(CntrGame::level));
    }
///////////////////////////////////////////////////////////////////
void creatGhostThr() {
       // pthread_create(&ghStatusThread, NULL, &Starter::changeGhostStateHelper, this);
        pthread_create(&ghStatusThreadB, NULL, &Starter::changeGhostStateHelperB, this);
        pthread_create(&ghStatusThreadI, NULL, &Starter::changeGhostStateHelperI, this);
        pthread_create(&ghStatusThreadP, NULL, &Starter::changeGhostStateHelperP, this);
        pthread_create(&ghStatusThreadC, NULL, &Starter::changeGhostStateHelperC, this);

    }

//  static void* changeGhostStateHelper(void* arg) {
//          static_cast<Starter*>(arg)->changeGhostState();
//          return NULL;
//     }

static void* changeGhostStateHelperB(void* arg) {
         static_cast<Starter*>(arg)->changeGhostStateB();
         return NULL;
    }
static void* changeGhostStateHelperI(void* arg) {
         static_cast<Starter*>(arg)->changeGhostStateI();
         return NULL;
    }
static void* changeGhostStateHelperP(void* arg) {
         static_cast<Starter*>(arg)->changeGhostStateP();
         return NULL;
    }
static void* changeGhostStateHelperC(void* arg) {
         static_cast<Starter*>(arg)->changeGhostStateC();
         return NULL;
    }
void changeGhostStateB()
    {		 
	       cout << "Start thread for GhostStatus "<<endl;			  
		   delay =  scaterInterval;
		   if (ghostStatus == Blue) 
		   {
			   delay = blueInterval; 
			   CntrGame::isBlueGhost = true;
		   }	  
		   Blinky->changeGhostState();
		   //cout << "Status=" << ghostStatus<< " Delay="<<delay<<" sec." << endl;
		  				   
			   curTime = time(0);
			   curTime += delay;			 
			  
			   while (true )
			   {
				   if (curTime <= time(0))  { break; }
			   }// wait for change ghost status
			    
			   sleep(milliseconds(10));
			   if (ghostStatus == Blue) // end blue time
			   {	
				 CntrGame::isBlueGhost = false;
				 CntrGame::ghostBonus = 100;
				 
			   }
			   if (ghostStatus == Attack)
			   {
				   ghostStatus = Scater;
				   delay = scaterInterval;
				   cout << "Scater " << endl;

			   }
			   else 
			   {			 
				   ghostStatus =  Attack;
				   delay = attackInterval;
				   cout << "Attack " << endl;
			   }
			    Blinky->changeGhostState();
			  
			  
			 
		   
		  cout << "Ended Thread GhostStatus" << endl;
		  cout << "************************" << endl;			   
    }
void changeGhostStateI()
    {		 
	       cout << "Start thread for GhostStatus "<<endl;			  
		   delay =  scaterInterval;
		   if (ghostStatus == Blue) 
		   {
			   delay = blueInterval; 
			   CntrGame::isBlueGhost = true;
		   }	  
		   Inky->changeGhostState();
		   //cout << "Status=" << ghostStatus<< " Delay="<<delay<<" sec." << endl;
		  				   
			   curTime = time(0);
			   curTime += delay;			 
			  
			   while (true )
			   {
				   if (curTime <= time(0))  { break; }
			   }// wait for change ghost status
			    
			   sleep(milliseconds(10));
			   if (ghostStatus == Blue) // end blue time
			   {	
				 CntrGame::isBlueGhost = false;
				 CntrGame::ghostBonus = 100;
				 
			   }
			   if (ghostStatus == Attack)
			   {
				   ghostStatus = Scater;
				   delay = scaterInterval;
				   cout << "Scater " << endl;

			   }
			   else 
			   {			 
				   ghostStatus =  Attack;
				   delay = attackInterval;
				   cout << "Attack " << endl;
			   }
			    Inky->changeGhostState();
			  
			  
			 
		   
		  cout << "Ended Thread GhostStatus" << endl;
		  cout << "************************" << endl;			   
    }

void changeGhostStateP()
    {		 
	       cout << "Start thread for GhostStatus "<<endl;			  
		   delay =  scaterInterval;
		   if (ghostStatus == Blue) 
		   {
			   delay = blueInterval; 
			   CntrGame::isBlueGhost = true;
		   }	  
		   Pinky->changeGhostState();
		   //cout << "Status=" << ghostStatus<< " Delay="<<delay<<" sec." << endl;
		  				   
			   curTime = time(0);
			   curTime += delay;			 
			  
			   while (true )
			   {
				   if (curTime <= time(0))  { break; }
			   }// wait for change ghost status
			    
			   sleep(milliseconds(10));
			   if (ghostStatus == Blue) // end blue time
			   {	
				 CntrGame::isBlueGhost = false;
				 CntrGame::ghostBonus = 100;
				 
			   }
			   if (ghostStatus == Attack)
			   {
				   ghostStatus = Scater;
				   delay = scaterInterval;
				   cout << "Scater " << endl;

			   }
			   else 
			   {			 
				   ghostStatus =  Attack;
				   delay = attackInterval;
				   cout << "Attack " << endl;
			   }
			    Pinky->changeGhostState();
			  
			  
			 
		   
		  cout << "Ended Thread GhostStatus" << endl;
		  cout << "************************" << endl;			   
    }

void changeGhostStateC()
    {		 
	       cout << "Start thread for GhostStatus "<<endl;			  
		   delay =  scaterInterval;
		   if (ghostStatus == Blue) 
		   {
			   delay = blueInterval; 
			   CntrGame::isBlueGhost = true;
		   }	  
		   Clyde->changeGhostState();
		   //cout << "Status=" << ghostStatus<< " Delay="<<delay<<" sec." << endl;
		  				   
			   curTime = time(0);
			   curTime += delay;			 
			  
			   while (true )
			   {
				   if (curTime <= time(0))  { break; }
			   }// wait for change ghost status
			    
			   sleep(milliseconds(10));
			   if (ghostStatus == Blue) // end blue time
			   {	
				 CntrGame::isBlueGhost = false;
				 CntrGame::ghostBonus = 100;
				 
			   }
			   if (ghostStatus == Attack)
			   {
				   ghostStatus = Scater;
				   delay = scaterInterval;
				   cout << "Scater " << endl;

			   }
			   else 
			   {			 
				   ghostStatus =  Attack;
				   delay = attackInterval;
				   cout << "Attack " << endl;
			   }
			    Clyde->changeGhostState();
			  
			  
			 
		   
		  cout << "Ended Thread GhostStatus" << endl;
		  cout << "************************" << endl;			   
    }

// void changeGhostState()
//     {		 
// 	       cout << "Start thread for GhostStatus "<<endl;			  
// 		   delay =  scaterInterval;
// 		   if (ghostStatus == Blue) 
// 		   {
// 			   delay = blueInterval; 
// 			   CntrGame::isBlueGhost = true;
// 		   }	  
// 		   changeStatus();
// 		   //cout << "Status=" << ghostStatus<< " Delay="<<delay<<" sec." << endl;
		  				   
// 			   curTime = time(0);
// 			   curTime += delay;			 
			  
// 			   while (true )
// 			   {
// 				   if (curTime <= time(0))  { break; }
// 			   }// wait for change ghost status
			    
// 			   sleep(milliseconds(10));
// 			   if (ghostStatus == Blue) // end blue time
// 			   {	
// 				 CntrGame::isBlueGhost = false;
// 				 CntrGame::ghostBonus = 100;
				 
// 			   }
// 			   if (ghostStatus == Attack)
// 			   {
// 				   ghostStatus = Scater;
// 				   delay = scaterInterval;
// 				   cout << "Scater " << endl;

// 			   }
// 			   else 
// 			   {			 
// 				   ghostStatus =  Attack;
// 				   delay = attackInterval;
// 				   cout << "Attack " << endl;
// 			   }
// 			   changeStatus();
			  
			  
			 
		   
// 		  cout << "Ended Thread GhostStatus" << endl;
// 		  cout << "************************" << endl;			   
//     }
/////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////
void resetLevel()
    {	
        gamestart = true;
        Inky->goHome();
        Blinky->goHome();
        Pinky->goHome();
        Clyde->goHome();
         CntrGame::pacIsDead = false;
        isCollid = false;	
        CntrGame::ghostBonus = 100;
        if(pac->pacLife<0)
        {		 
            gameText->gameOverTxt.setString("GAME OVER"); 
        }
    }
void stopAll()
    {					
        pac->stop();
        Blinky->stop();
        Pinky->stop();
        Inky->stop();
        Clyde->stop();	
        CntrGame::gameRun = false;
        // gameText->stopThread();
        // fruit->stop();
        // gmSound->stopAll();
        // if (ghStatusThread.joinable() ){ ghStatusThread.detach(); }	
        resetLevel();

        wait(2);
        if (pac->pacLife >= 0) { startLevel(); }				
    }
    
    void resetPacGhost()
    {
        pac->reset();
        Blinky->reset();
        Pinky->reset();
        Inky->reset();
        Clyde->reset();		
    }
    void changeStatus()
    {
        Blinky->changeGhostState();
        Pinky->changeGhostState();
        Inky->changeGhostState();
        Clyde->changeGhostState();
    }
    void wait(int delayInt)
    {
        auto curTime = time(0);
        int counter=0;
        curTime += delayInt;		
        while (true)
        {
            counter++;
            if (toNextLevel)
            {		
                if (counter % 30 == 0)
                {
                backSpr.setTexture(backFlashText);
                }
                else if (counter % 30 == 15)
                {
                backSpr.setTexture(backText);
                }				
            }
            if (curTime < time(0)) { break; }
            sleep(milliseconds(10));
        }
        toNextLevel = false;
        backSpr.setTexture(backText);
    }
 ~Starter() {
       
    delete  Blinky; 
    delete Pinky;
    delete Inky;
    delete Clyde;
        // pthread_mutex_destroy(&mtx) ;
        // pthread_exit (NULL) ;
    }


};