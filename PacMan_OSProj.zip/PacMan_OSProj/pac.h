#include <pthread.h>
#include <unistd.h>
#include <iostream>
#include "cntrgame.h"
using namespace std;
using namespace sf;

pthread_mutex_t m2;
enum PacDirection
{
 Up,Right,Down,Left
} pacDirection,pacPrevDirection;

template <class C>
class Pac : public CntrGame
{
public:
C* starter;
sf::Keyboard::Key key1;
int pacLife = 3;
    Pac(Texture* texture,C *_starter)
        {
            std::cout << "Pac class OK \n";
            starter = _starter;
            pacSpr.setTexture(*texture);
            lifeSpr.setTexture(*texture);
           // pthread_mutex_init(&m2,NULL);        
            init();         
        };
    Sprite getSprite()
        {
            return pacSpr;
        };
    Sprite getLifeSpr()
        {
            return lifeSpr;
        }

    void rotation(sf::Keyboard::Key key)
        {
            key1 = key;
            cout<<"Pac Rotation OK"<<endl;
            
            if (checkKeyPress(key))
            {
                //pthread_create(&pacThread,NULL,&Pac::moveHelper,(void *) &key);
                move(key);           
            }
            
        }
static void* moveHelper(void* arg) {
    
        sf::Keyboard::Key  * key1 = (sf::Keyboard::Key*) arg;
         
        static_cast<Pac*>(arg)->move(* key1);
        return NULL;
    }
    void reset()
        {
            CntrGame::pacIsDead = false;
            pacAnim = moveX = moveY = 0;
            pacRot = 0;             
            forwX = 1, forwY = 0;
            pacDirection = pacPrevDirection = Right;
            if (gameStatus == Demo)
            {
                setGridPosition(demoPos[0][0], demoPos[0][1]);
                pacDirection = pacPrevDirection = Left;
            }
            else {  setGridPosition(startX, startY); }
            pacSpr.setPosition(pacPos);
            stop();
        }

public:
    pthread_mutex_t mutex;
    pthread_t pacThread;
    float pacAnim = 0;
    float pacRot = 0;   
    Sprite pacSpr;  
    Sprite lifeSpr;
    int forwX = 1,forwY=0;
    int startX =  11;
    int startY =  18; 

    void init()
        {       
            sprW = 30; sprH = 30; sprOfsX = 0; sprOfsY = 0;
            speed = 6;        
            pacSpr.setOrigin(sprW / 2, sprH / 2);
            pacSpr.setTextureRect(IntRect(sprOfsX, sprOfsY, sprW, sprH));  
            lifeSpr.setTextureRect(IntRect(30, 0, sprW, sprH));           
            lifeSpr.scale(.8,.8);
            reset();
            cout<<"Pac Class Ok"<<endl;
            //loop();
            //pthread_mutex_init(&mutex, NULL);
            //pthread_create(&loopThread, NULL, &loop, NULL);
           
        }
 
 
   
     void move(sf::Keyboard::Key key)
        {          
            if (gameStatus == Demo) { return; }
            //forwX = forwY = 0;
            switch (key)
            {
            case sf::Keyboard::Up :         
                pacDirection = Up;                             
                break;

            case sf::Keyboard::Right:           
                pacDirection = Right;
                break;

            case sf::Keyboard::Down:                                   
                pacDirection = Down;         
                break;

            case sf::Keyboard::Left:
                if (pacRot==std::abs(180) ) { return; }     
                pacDirection = Left;   
                break;      
            }              
        }

    void direction(PacDirection direct)
        {       
            forwX = forwY = 0;
            switch (direct)
            {
            case Up:
                moveY = -speed; moveX = 0;
                forwY = -1;
                pacRot = -90;         
                break;

            case Right:
                moveY = 0; moveX = speed;
                forwX = 1;
                pacRot = 0;
                break;

            case Down:
                moveY = speed; moveX = 0;
                forwY = 1;
                pacRot = 90;
                break;
            case Left:
                moveY = 0; moveX = -speed;
                forwX = -1;
                pacRot = 180;          
                break;
            }
            if (pacRot != pacSpr.getRotation())
            {
                pacRot -= pacSpr.getRotation();
                setRotation(pacRot);
            }
        }
     bool checkKeyPress(sf::Keyboard::Key key)
        {
            return key == sf::Keyboard::Up    ||
                    key == sf::Keyboard::Right ||
                    key == sf::Keyboard::Down  ||
                    key == sf::Keyboard::Left;
        }
     void setRotation(float rot)
        {         
            pacSpr.rotate(rot);
        }
     int getPosGridX()
        {
        return  (pacSpr.getPosition().x ) / sprW;
        }

 //---
    int getPosGridY()
        {
            return  (pacSpr.getPosition().y ) / sprH;
        }

    void animation()
        {    //cout<<"Pac Class Ok animation"<<endl; 
            //string str = getMazeStr(getPosGridX(),getPosGridY());
            if (getPosGridX() > 21)
            {
                setGridPosition(0, 11);
            }
            else if (getPosGridX() < 0)
            {
                moveX = 0;
                setGridPosition(21, 11);
            }
            if (xyModul())
            {
                
                direction(pacDirection);
                if (collidWall())
                {   
                if (pacDirection == pacPrevDirection) 
                    {
                    moveX = moveY = 0;
                    pacPrevDirection = pacDirection;
                    //   if (abs(forwX) == 1) {  moveX = 0; }
                    //   if (abs(forwY) == 1) {  moveY = 0; }
                    }
                else 
                {     
                    direction(pacPrevDirection);
                }             
                }
                
                pacPrevDirection = pacDirection;
            }

            if ( xyModul() && collidWall()  )
            {
                moveX = moveY = 0;
            }       
            else if (!stopMove  )
            {
                pacPos.x += moveX; pacPos.y += moveY;
                pacSpr.setPosition(pacPos);
                if (xyModul() ) { eatDot(getPosGridX(), getPosGridY()); }
            }
            //else { pacAnim = 0; }        
            // fruit 
            // if (getMazeStr(getPosGridX(), getPosGridY() )=="1" && starter->fruit->getVisible() )
            // {
            //     int bonus = 100 * CntrGame::level;
        
            //     setScore(bonus);
            //     starter->gameText->showBonus(bonus ,  starter->fruit->getPosition(),true );
            //     starter->fruit->setVisible(false);
            // }


            sprOfsX = (sprW * (int)pacAnim);
            pacSpr.setTextureRect(sf::IntRect(sprOfsX, sprOfsY, sprW, sprH));
            CntrGame::pacPosition=&pacPos;
        }
    void eatDot(int pacX, int pacY)
    {
        for (int i = 0; i < maze->dotsCount; i++)
        {
            CircleShape dot = maze->dotsArr[i];
            Vector2f pos = dot.getPosition();
            int dotX = (int)(pos.x / sprW);
            int dotY = (int)(pos.y / sprH);
            if (dotX == pacX && dotY == pacY && !starter->isCollid)
            {
                if (dot.getFillColor() != Color::Black)
                {
                    
                    if (dot.getRadius() == 10)// big dot
                    {
                       // pthread_mutex_lock(&m2);
                        CntrGame::score += 20;                       
                        if (starter->blueInterval > 0)
                        {
                            CntrGame::isBlueGhost = true;
                            starter->setBlueGhost();
                        }

                        dot.setFillColor(Color::Black);
                        maze->dotsArr[i] = dot;
                        CntrGame::dotsEat++;         
                        setScore(dotBonus);
                       // pthread_mutex_unlock(&m2);
                        break;
                    }
                    else{
                        dot.setFillColor(Color::Black);
                        maze->dotsArr[i] = dot;
                        CntrGame::dotsEat++;         
                        setScore(dotBonus);
                        break;
                    }
                    
                }

            }
        }
    }

   void setScore(int score)
    {
        CntrGame::score += score;
        starter->gameText->scoreTxt.setString("SCORE: " + to_string(CntrGame::score));
    }

   //---
   bool collidWall()
    {
        return checkMazeGrid(getPosGridX() + forwX, getPosGridY() + forwY);
    }

   

   //---
   bool xyModul()
    {
        modulX = (int)pacSpr.getPosition().x % sprW;
        modulY = (int)pacSpr.getPosition().y % sprH;
        return modulX == 15 && modulY == 15;
    }

   //---
   void stopLoop()
    {
        pthread_cancel(pacThread);
      // pthread_mutex_destroy(&mutex);
    }

   //---
   void setGridPosition(int x, int y)
    {
        pacPos = sf::Vector2f((x * 30) + (sprW / 2), (y * 30) + (sprH / 2));        
    }   
    };
