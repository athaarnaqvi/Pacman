#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include <chrono>
//bonus thread remaining


using namespace std;
using namespace sf;
class GameText
{
public:
	 
	    Font fnt;
		Text enterTxt;
		Text gameOverTxt;
		Text scoreTxt;
		Text bonusTxt;
		Text levelTxt;
		Text countTxt;
		Text targetPointTxt;
		RenderWindow* window;
        int *totalTime;
        int curTime;
        int delay = 2;// seconds
GameText()//RenderWindow *win)
{
	cout << "TextGame class OK" << endl;
	//window = win;
	fnt.loadFromFile("font/comic.ttf");
	setText();		 
}

Text getGhostNameTxt(string name)
{
	Text* txt = new Text();
	txt->setFont(fnt);
	txt->setString(name);
	txt->setFillColor(Color::White);
	txt->setCharacterSize(25);
	return *txt;
}

void setText()
{
	enterTxt.setFont(fnt);
	enterTxt.setString("PRESS ENTER");
	enterTxt.setCharacterSize(35);
	enterTxt.setPosition(Vector2f(300, 500));

   


	scoreTxt.setFont(fnt);
	scoreTxt.setString("SCORE:");
	scoreTxt.setCharacterSize(22);
	scoreTxt.setPosition( getGridPosXY(1,0));

	levelTxt.setFont(fnt);
	levelTxt.setString("LEVEL:");
	levelTxt.setCharacterSize(18);
	levelTxt.setPosition(getGridPosXY(19, 24));
	
	countTxt.setFont(fnt);
	countTxt.setFillColor(Color::Red);
	countTxt.setString("");
	countTxt.setCharacterSize(35);
	countTxt.setOutlineColor(Color::White);
	countTxt.setOutlineThickness(2);
	countTxt.setPosition(getGridPosXY(11, 14));

	bonusTxt.setFont(fnt);
	bonusTxt.setString("");
	bonusTxt.setCharacterSize(26);
	bonusTxt.setFillColor(Color::Blue);
	bonusTxt.setOutlineColor(Color::White);
	bonusTxt.setOutlineThickness(2);

	gameOverTxt.setFont(fnt);
	gameOverTxt.setString("");
	gameOverTxt.setCharacterSize(35);
	gameOverTxt.setFillColor(Color::Red);
	gameOverTxt.setOutlineColor(Color::White);
	gameOverTxt.setOutlineThickness(2);
	gameOverTxt.setPosition(getGridPosXY(8, 14));


	 targetPointTxt.setFont(fnt);
	 targetPointTxt.setString("*");
	 targetPointTxt.setCharacterSize(25);
	 targetPointTxt.setFillColor(Color::Green);
	 //targetPointTxt.setOutlineColor(Color::White);
	 targetPointTxt.setOutlineThickness(1);
}


//---
Vector2f getGridPosXY(float x,float y)
{
	return Vector2f(x*30, y*30);
}


};